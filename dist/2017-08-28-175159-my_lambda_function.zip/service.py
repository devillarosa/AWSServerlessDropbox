# -*- coding: utf-8 -*-
import pymysql

def handler(event, context):
    print("Hello World")
    # Your code goes here!
