# -*- coding: utf-8 -*-
import pymysql

def handler(event, context):
    # Your code goes here!
